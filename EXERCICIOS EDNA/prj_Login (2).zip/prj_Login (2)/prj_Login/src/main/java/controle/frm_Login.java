/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;


import conexao.Conexao;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author dti
 */
public class frm_Login extends JFrame {
    Conexao con_cliente;
    JPasswordField tsen;
    JLabel rusu, rsen, rtit;
    JTextField tusu;
    JButton blogar;
    
    public frm_Login(){
        con_cliente = new Conexao();
        con_cliente.conecta();
     
        setTitle("LOGIN DE ACESSO");
        Container tela = getContentPane();
        ImageIcon icon = new ImageIcon("mymelody.jpg");
        setIconImage(icon.getImage());
        setLayout(null);
        getContentPane().setBackground(new Color(255,192,203));
       
        //JLABEL
        rtit = new JLabel("ACESSO AO SISTEMA");
        rusu = new JLabel ("Usuário: ");
        rsen = new JLabel ("Senha: ");

         //JBUTTON
        blogar = new JButton("Logar");
        
        //JPASSWORDFIELD
        tsen = new JPasswordField();
        
         //JTEXTFIELD
         tusu = new JTextField(3);

        //SETBOUNDS
        rtit.setBounds   (350,100,1000,20);
        rusu.setBounds   (200,150,100,20);
        rsen.setBounds   (200,180,100,20);
        blogar.setBounds (350,220,100,20);
        tsen.setBounds   (250,180,300,20);
        tusu.setBounds   (250,150,300,20); 

       //FUNÇÕES
       //LOGAR
       blogar.addActionListener( new ActionListener(){
           public void actionPerformed(ActionEvent e){
               try{
               String pesquisa = "select * from tblusuario where usuario = '" + tusu.getText() + "' and senha = '" + tsen.getText() + "'";
               con_cliente.executaSQL(pesquisa);
               
               if(con_cliente.resultset.first()){
               FrmTelaCad mostra = new FrmTelaCad();
               mostra.setVisible(true);
               dispose();
               }else{
               JOptionPane.showMessageDialog(null,"\n usúario não cadastrado :(", "Mensagem do Programa",JOptionPane.INFORMATION_MESSAGE);
               con_cliente.desconecta();
               System.exit(0);
               }
               }catch(SQLException errosql){
               JOptionPane.showMessageDialog(null, "os dados não foram localizados :( :\n"+errosql,"Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
               }
           }
       });
      
       //TELAADD
       tela.add(rtit);
       tela.add(rusu);
       tela.add(rsen);
       tela.add(blogar);
       tela.add(tsen);
       tela.add(tusu);

        //fim da cofiguração da jtable
        //SETS
        setResizable(false);
        setSize(800,600);
        setVisible(true);
        setLocationRelativeTo(null);
    }
    public static void main(String args[]){
    frm_Login app = new frm_Login(); 
    app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }
}