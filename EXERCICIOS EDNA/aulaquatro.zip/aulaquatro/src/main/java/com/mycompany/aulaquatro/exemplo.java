/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aulaquatro;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

/**
 *
 * @author dti
 */
public class exemplo extends JFrame {
    JList lista;
    JComboBox listanova,listanova2;
    String cidades[] = {"Rio de Janeiro", "São Paulo", "Minas Gerais", "Espírito Santo", "Bahia", "Pernambuco", "Rio Grande do Sul","Acre"};
    JButton exibir,exibir2,exibir3;
    JLabel rotulo, rotulo2,rotulo3, f;
    
    //JLIST
    public exemplo(){
        super ("TABELAS EXEMPLO 4");
        Container tela = getContentPane();
        ImageIcon icone = new ImageIcon("hello.jpg");
        setIconImage(icone.getImage());
        setLayout(null);
        
        //JLIST COMANDOS
        exibir = new JButton("EXIBIR"); 
        rotulo = new JLabel("TABELA JLIST");
        lista = new JList(cidades);
        lista.setVisibleRowCount(5);
        JScrollPane painelRolagem = new JScrollPane(lista);
        lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        painelRolagem.setBounds(40,50,150,100);
        exibir.setBounds(200,50,100,30);
        rotulo.setBounds(40,150,200,30);
        lista.setForeground(Color.red);
        lista.setBackground(Color.yellow);
        lista.setFont(new Font("ARIAL",Font.BOLD,12));
        
        //JCOMBOBOX1 COMANDO 
        exibir2 = new JButton("EXIBIR");
        rotulo2 = new JLabel("TABELA JCOMBOBOX 1"); 
        listanova = new JComboBox (cidades);
        listanova.setMaximumRowCount(5);
        listanova.setBounds(350,50,150,30);
        exibir2.setBounds(510,50,100,30);
        rotulo2.setBounds(350,90,200,30);
        listanova.setForeground(Color.red);
        listanova.setBackground(Color.yellow);
        listanova.setFont(new Font("ARIAL",Font.BOLD,12));
        
        
        //JCOMBOBOX2 COMANDO
        exibir3 = new JButton("EXIBIR");
        rotulo3 = new JLabel("TABELA COMBO BOX 2"); 
        listanova2 = new JComboBox (cidades);
        listanova2.setEditable (true);
        listanova2.setMaximumRowCount(5);
        listanova2.setBounds(680,50,150,30);
        exibir3.setBounds(840,50,100,30);
        rotulo3.setBounds(680,90,200,30);
        listanova2.setForeground(Color.red);
        listanova2.setBackground(Color.yellow);
        listanova2.setFont(new Font("ARIAL",Font.BOLD,12));
        
        //EXIBIR JLIST
        exibir.addActionListener(
        new ActionListener(){
        public void actionPerformed(ActionEvent e){
        rotulo.setText("O estado é "+lista.getSelectedValue().toString());}});
        
        exibir.addActionListener(
        new ActionListener(){
        public void actionPerformed(ActionEvent e){
        Object selecionados[] = lista.getSelectedValues();
        String resultados = "Valores selecionados:\n";
        for(int i=0; i<selecionados.length;i++)
        resultados+=selecionados[i].toString()+"\n";
        JOptionPane.showMessageDialog(null,resultados);}});
       
        //EXIBIR COMANDOS COMBOX 1
        exibir2.addActionListener(
        new ActionListener(){
        public void actionPerformed(ActionEvent e){
        rotulo2.setText("O estado é "+listanova.getSelectedItem().toString());{ }}});
        
        //EXIBIR COMANDOS COMBOX 1
        exibir3.addActionListener(
        new ActionListener(){
        public void actionPerformed(ActionEvent e){ 
        rotulo3.setText("O estado é "+listanova2.getSelectedItem().toString());{}}});
        
        //ADICIONANDO TELAS
        tela.add(painelRolagem);
        tela.add(exibir);
        tela.add(rotulo);
        tela.add(listanova);
        tela.add(exibir2);
        tela.add(rotulo2);
        tela.add(listanova2);
        tela.add(exibir3);
        tela.add(rotulo3);
        setSize(400,250);
        setVisible(true);    
        setExtendedState(MAXIMIZED_BOTH);
}
    public static void main(String args[]){
        exemplo app = new exemplo();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
