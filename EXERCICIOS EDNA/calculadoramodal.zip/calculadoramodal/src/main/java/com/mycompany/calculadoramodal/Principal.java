/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calculadoramodal;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Frame;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.UIManager;


/**
 *
 * @author giova
 */
    
public class Principal extends JFrame{
    
//DECLARAÇÃO DE VARIAVEIS
JMenuBar barra;
JMenu sobre, operacoes, sair;
JMenuItem somar, dividir, multiplicar, subtrair, sobremim, saindo;
Soma segundajanela; 
Divisao terceirajanela;
Multiplicar quartajanela;
Subtrair quintajanela;
Sobremim sextajanela;
JToolBar barra1;
JButton soma, div, mult, sub, saida;
ImageIcon imagens[];
JPopupMenu opcoes;
JMenuItem sobre1, sair1;
        
//PRIMEIRA "CLASSE" PRINCIPAL
public Principal(){
super("MENU CALCULADORA");
Container tela = getContentPane();
tela.setLayout(null);
ImageIcon icone = new ImageIcon("img/iconecalc.png");
setIconImage(icone.getImage());

       opcoes = new JPopupMenu();
        sobre1 = new JMenuItem("SOBRE");
        sair1 = new JMenuItem("SAIR");

        tela.addMouseListener(new MouseAdapter(){
            public void mouseReleased(MouseEvent e){
                if(e.isPopupTrigger())
                    opcoes.show(e.getComponent(), e.getX(), e.getY());
            }
        });

        opcoes.add(sobre1);
        opcoes.add(sair1);
//TOOLBAR
 setIconImage(icone.getImage());
    String icones[]={"img/iconesoma1.png","img/iconediv1.png", "img/iconemult1.png","img/iconesub1.png","img/iconesair.png"};
    imagens = new ImageIcon[5];
    for(int i=0;i<5;i++){
    imagens[i] = new ImageIcon(icones[i]);}
    soma = new JButton(imagens[0]);
    div = new JButton(imagens[1]);
    mult = new JButton(imagens[2]);
    sub = new JButton(imagens[3]);
    saida = new JButton(imagens[4]);
    soma.setToolTipText("SOMA");
    div.setToolTipText("DIVISÃO");
    mult.setToolTipText("MULTIPLICAÇÃO");
    sub.setToolTipText("SUBTRAÇÃO");
    saida.setToolTipText("FECHAR PÁGINA");
    barra1 = new JToolBar("BARRA DE FERRAMENTAS :)");
    UIManager.put("ToolTip.background",SystemColor.info);
    UIManager.put("ToolTip.foreground",Color.blue);
    barra1.setBackground(new Color(255, 219, 224)); 
    barra1.setRollover(true);
    barra1.add(soma);barra1.add(div);barra1.add(mult);barra1.add(sub);barra1.add(saida);
    barra1.setBounds(1,1,220,50);
    tela.add(barra1);
    setSize(320,340);
    setLocationRelativeTo(null);
    setVisible(true);
//DECLARANDO O JMENUBAR
barra = new JMenuBar();
setJMenuBar(barra);

//DECLARANDO OS JMENUS
sobre = new JMenu("Sobre");
operacoes = new JMenu("Operações");
sair = new JMenu("Fechar Janelas");

//DECLARANDO O JMENUITEM
somar = new JMenuItem("Somar");
dividir = new JMenuItem("Dividir");
multiplicar= new JMenuItem("Multiplicar");
subtrair = new JMenuItem("Subtrair");
sobremim = new JMenuItem("Sobre mim");
saindo = new JMenuItem("Sair");

//ENCAMINHANDO PARA CLASSE SOBRE MIM
sobremim.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
sextajanela = new Sobremim (null,"SOBRE MIM",true);
sextajanela.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
sextajanela.setVisible(true);}}); 

sobre1.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
sextajanela = new Sobremim (null,"SOBRE MIM",true);
sextajanela.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
sextajanela.setVisible(true);}});

//ENCAMINHANDO PARA CLASSE SOMA
somar.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
segundajanela = new Soma (null,"SOMA",true);
segundajanela.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
segundajanela.setVisible(true);}});  

soma.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
segundajanela = new Soma (null,"SOMA",true);
segundajanela.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
segundajanela.setVisible(true);}}); 

//ENCAMINHANDO PARA CLASSE DIVIDIR
dividir.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
terceirajanela = new Divisao (null,"DIVIDIR",true);
terceirajanela.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
terceirajanela.setVisible(true);}});
   
div.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
terceirajanela = new Divisao (null,"DIVIDIR",true);
terceirajanela.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
terceirajanela.setVisible(true);}});

//ENCAMINHANDO PARA CLASSE MULTIPLICAR
multiplicar.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
quartajanela = new Multiplicar (null,"MULTIPLICAR",true);
quartajanela.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
quartajanela.setVisible(true);}});  

mult.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
quartajanela = new Multiplicar (null,"MULTIPLICAR",true);
quartajanela.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
quartajanela.setVisible(true);}});

//ENCAMINHANDO PARA CLASSE SUBTRAIR
subtrair.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
quintajanela = new Subtrair (null,"SUBTRAIR",true);
quintajanela.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
quintajanela.setVisible(true);}}); 
 
sub.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
quintajanela = new Subtrair (null,"SUBTRAIR",true);
quintajanela.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
quintajanela.setVisible(true);}}); 

saindo.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
int opcao;
Object[]botoes={"Sim","Não"};
opcao=JOptionPane.showOptionDialog(null,"Deseja mesmo fechar a janela?","Fechar",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,botoes,botoes[0]);
if(opcao==JOptionPane.YES_OPTION)System.exit(0);}});
  
saida.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
int opcao;
Object[]botoes={"Sim","Não"};
opcao=JOptionPane.showOptionDialog(null,"Deseja mesmo fechar a janela?","Fechar",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,botoes,botoes[0]);
if(opcao==JOptionPane.YES_OPTION)System.exit(0);}});

sair1.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
int opcao;
Object[]botoes={"Sim","Não"};
opcao=JOptionPane.showOptionDialog(null,"Deseja mesmo fechar a janela?","Fechar",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,botoes,botoes[0]);
if(opcao==JOptionPane.YES_OPTION)System.exit(0);}});
//ADICIONANDO COR DE FUNDO NAS TELAS
tela.setBackground(new Color(255, 231, 234));
barra.setBackground(new Color(255, 219, 224));  

//ADICIONANDO TELAS VISIVEIS
barra.add(operacoes);
barra.add(sobre);
barra.add(sair);
operacoes.add(somar);
operacoes.add(dividir);
operacoes.add(multiplicar);
operacoes.add(subtrair);
sobre.add(sobremim);
sair.add(saindo);
setSize(500, 550);
setVisible(true);
setLocationRelativeTo(null);
}
public static void main(String args[]){
Principal app = new Principal();
app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);}
  //CLASSE SOMA - COMANDOS 
class Soma extends JDialog{
JButton sair;
JLabel rotulo1, rotulo2, exibir, mensagem;
JTextField texto1, texto2;
JButton somar2n, voltar,limpar;

public Soma (Frame owner, String title,boolean modal){
super(owner,title,modal);
Container tela1 = getContentPane();
tela1.setLayout(null);
ImageIcon icone = new ImageIcon("img/iconesoma.png");
setIconImage(icone.getImage());

// JLABEL
mensagem = new JLabel ("Bem-vindo(a)! ao teste da minha calculadora de soma:)");
rotulo1 = new JLabel("1º Número: ");
rotulo2 = new JLabel("2º Número: ");


//JTEXTFIELD 
texto1 = new JTextField(5);
texto2 = new JTextField(5);

//JLABEL
exibir = new JLabel("");

//JBUTTON
somar2n = new JButton("Somar");

//BACKGROUND COLOR - COR DE FUNDO
tela1.setBackground(new Color(255, 243, 244));

//SETBOUNDS
mensagem.setBounds(50,20,1000,20);
rotulo1.setBounds(50,60,100,20);
rotulo2.setBounds(50,100,100,20);
texto1.setBounds(120,60,200,20);
texto2.setBounds(120,100,200,20);
exibir.setBounds(50,140,200,20);
somar2n.setBounds(50,175,100,20);

//COMANDOS DA CONTA SOMA
somar2n.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
int numero1, numero2, soma;soma = 0;numero1 = Integer.parseInt(texto1.getText());
numero2 = Integer.parseInt(texto2.getText());soma = numero1 + numero2;exibir.setVisible(true);
exibir.setText("A SOMA É: "+soma);}});
exibir.setVisible(false);

//COMANDOS VOLTAR
voltar = new JButton("Voltar");
voltar.setBounds(50,200,100,20);
voltar.addActionListener(
new ActionListener(){
public void actionPerformed(ActionEvent e) {
segundajanela.dispose();}});
tela1.add(voltar); 

//COMANDOS LIMPAR
limpar = new JButton("Limpar");
limpar.setBounds(50,225,100,20);
limpar.addActionListener( new ActionListener(){
public void actionPerformed(ActionEvent e) {
texto1.setText(null);
texto2.setText(null);
exibir.setText(null);
texto1.requestFocus();}});
tela1.add(limpar);

//COMANDOS SAIR
sair = new JButton("Sair");
sair.setBounds(50,250,100,20);
sair.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
int opcao;
Object[]botoes={"Sim","Não"};
opcao=JOptionPane.showOptionDialog(null,"Deseja mesmo fechar a janela?","Fechar",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,botoes,botoes[0]);
if(opcao==JOptionPane.YES_OPTION)System.exit(0);}});

TBsair tsair = new TBsair();
sair.addActionListener(tsair);
tela1.add(sair);

//ADICIONANDO TELAS
tela1.add(rotulo1);
tela1.add(rotulo2);
tela1.add(texto1);
tela1.add(texto2);
tela1.add(exibir);
tela1.add(somar2n);
tela1.add(mensagem);

setSize(400,400);
setLocationRelativeTo(null);}}

//CLASSE DIVISAO - COMANDOS 
class Divisao extends JDialog{
JButton sair;
JLabel rotulo1, rotulo2, exibir, mensagem;
JTextField texto1, texto2;
JButton somar2n, voltar,limpar;

public Divisao (Frame owner, String title,boolean modal){
super(owner,title,modal);
Container tela2 = getContentPane();
tela2.setLayout(null);
ImageIcon icone = new ImageIcon("img/iconediv.png");
setIconImage(icone.getImage());

// JLABEL
mensagem = new JLabel ("Bem-vindo(a)! ao teste da minha calculadora de divisão:)");
rotulo1 = new JLabel("1º Número: ");
rotulo2 = new JLabel("2º Número: ");

//JTEXTFIELD 
texto1 = new JTextField(5);
texto2 = new JTextField(5);

//JLABEL
exibir = new JLabel("");

//JBUTTON
somar2n = new JButton("Dividir");

//BACKGROUND COLOR - COR DE FUNDO
tela2.setBackground(new Color(255, 243, 244));

//SETBOUNDS
mensagem.setBounds(50,20,1000,20);
rotulo1.setBounds(50,60,100,20);
rotulo2.setBounds(50,100,100,20);
texto1.setBounds(120,60,200,20);
texto2.setBounds(120,100,200,20);
exibir.setBounds(50,140,200,20);
somar2n.setBounds(50,175,100,20);

//COMANDOS DA CONTA DIVIDIR
somar2n.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
int numero1, numero2, soma;soma = 0;numero1 = Integer.parseInt(texto1.getText());
numero2 = Integer.parseInt(texto2.getText());soma = numero1 / numero2;exibir.setVisible(true);
exibir.setText("A DIVISÃO É: "+soma);}});
exibir.setVisible(false);

//COMANDOS VOLTAR
voltar = new JButton("Voltar");
voltar.setBounds(50,200,100,20);
voltar.addActionListener(
new ActionListener(){
public void actionPerformed(ActionEvent e) {
terceirajanela.dispose();}});
tela2.add(voltar); 

//COMANDOS LIMPAR
limpar = new JButton("Limpar");
limpar.setBounds(50,225,100,20);
limpar.addActionListener( new ActionListener(){
public void actionPerformed(ActionEvent e) {
texto1.setText(null);
texto2.setText(null);
exibir.setText(null);
texto1.requestFocus();}});
tela2.add(limpar);

//COMANDOS SAIR
sair = new JButton("Sair");
sair.setBounds(50,250,100,20);
sair.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
int opcao;
Object[]botoes={"Sim","Não"};
opcao=JOptionPane.showOptionDialog(null,"Deseja mesmo fechar a janela?","Fechar",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,botoes,botoes[0]);
if(opcao==JOptionPane.YES_OPTION)System.exit(0);}});

TBsair tsair = new TBsair();
sair.addActionListener(tsair);
tela2.add(sair);

//ADICIONANDO TELAS
tela2.add(rotulo1);
tela2.add(rotulo2);
tela2.add(texto1);
tela2.add(texto2);
tela2.add(exibir);
tela2.add(somar2n);
tela2.add(mensagem);

setSize(400,400);
setLocationRelativeTo(null);}}

class TBsair implements ActionListener{
    public void actionPerformed(ActionEvent evento){
      }
    }
 
//CLASSE SOMA - COMANDOS 
class Multiplicar extends JDialog{
JButton sair;
JLabel rotulo1, rotulo2, exibir, mensagem;
JTextField texto1, texto2;
JButton somar2n, voltar,limpar;

public Multiplicar (Frame owner, String title,boolean modal){
super(owner,title,modal);
Container tela2 = getContentPane();
tela2.setLayout(null);
ImageIcon icone = new ImageIcon("img/iconemult.png");
setIconImage(icone.getImage());

// JLABEL
mensagem = new JLabel ("Bem-vindo(a)! ao teste da minha calculadora de multiplicar:)");
rotulo1 = new JLabel("1º Número: ");
rotulo2 = new JLabel("2º Número: ");


//JTEXTFIELD 
texto1 = new JTextField(5);
texto2 = new JTextField(5);

//JLABEL
exibir = new JLabel("");

//JBUTTON
somar2n = new JButton("Multiplicar");

//BACKGROUND COLOR - COR DE FUNDO
tela2.setBackground(new Color(255, 243, 244));

//SETBOUNDS
mensagem.setBounds(40,20,1000,20);
rotulo1.setBounds(50,60,100,20);
rotulo2.setBounds(50,100,100,20);
texto1.setBounds(120,60,200,20);
texto2.setBounds(120,100,200,20);
exibir.setBounds(50,140,200,20);
somar2n.setBounds(50,175,100,20);

//COMANDOS DA CONTA SOMA
somar2n.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
int numero1, numero2, soma;soma = 0;numero1 = Integer.parseInt(texto1.getText());
numero2 = Integer.parseInt(texto2.getText());soma = numero1 * numero2;exibir.setVisible(true);
exibir.setText("A MULTIPLICAÇÃO: "+soma);}});
exibir.setVisible(false);

//COMANDOS VOLTAR
voltar = new JButton("Voltar");
voltar.setBounds(50,200,100,20);
voltar.addActionListener(
new ActionListener(){
public void actionPerformed(ActionEvent e) {
quartajanela.dispose();}});
tela2.add(voltar); 

//COMANDOS LIMPAR
limpar = new JButton("Limpar");
limpar.setBounds(50,225,100,20);
limpar.addActionListener( new ActionListener(){
public void actionPerformed(ActionEvent e) {
texto1.setText(null);
texto2.setText(null);
exibir.setText(null);
texto1.requestFocus();}});
tela2.add(limpar);

//COMANDOS SAIR
sair = new JButton("Sair");
sair.setBounds(50,250,100,20);
sair.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
int opcao;
Object[]botoes={"Sim","Não"};
opcao=JOptionPane.showOptionDialog(null,"Deseja mesmo fechar a janela?","Fechar",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,botoes,botoes[0]);
if(opcao==JOptionPane.YES_OPTION)System.exit(0);}});

TBsair tsair = new TBsair();
sair.addActionListener(tsair);
tela2.add(sair);

//ADICIONANDO TELAS
tela2.add(rotulo1);
tela2.add(rotulo2);
tela2.add(texto1);
tela2.add(texto2);
tela2.add(exibir);
tela2.add(somar2n);
tela2.add(mensagem);

setSize(400,400);
setLocationRelativeTo(null);}}

//CLASSE SOMA - COMANDOS 
class Subtrair extends JDialog{
JButton sair;
JLabel rotulo1, rotulo2, exibir, mensagem;
JTextField texto1, texto2;
JButton somar2n, voltar,limpar;

public Subtrair (Frame owner, String title,boolean modal){
super(owner,title,modal);
Container tela4 = getContentPane();
tela4.setLayout(null);
ImageIcon icone = new ImageIcon("img/iconesub.png");
setIconImage(icone.getImage());

// JLABEL
mensagem = new JLabel ("Bem-vindo(a)! ao teste da minha calculadora de subtração:)");
rotulo1 = new JLabel("1º Número: ");
rotulo2 = new JLabel("2º Número: ");


//JTEXTFIELD 
texto1 = new JTextField(5);
texto2 = new JTextField(5);

//JLABEL
exibir = new JLabel("");

//JBUTTON
somar2n = new JButton("Subtrair");

//BACKGROUND COLOR - COR DE FUNDO
tela4.setBackground(new Color(255, 243, 244));

//SETBOUNDS
mensagem.setBounds(50,20,1000,10);
rotulo1.setBounds(50,60,100,20);
rotulo2.setBounds(50,100,100,20);
texto1.setBounds(120,60,200,20);
texto2.setBounds(120,100,200,20);
exibir.setBounds(50,140,200,20);
somar2n.setBounds(50,175,100,20);

//COMANDOS DA CONTA SOMA
somar2n.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
int numero1, numero2, soma;soma = 0;numero1 = Integer.parseInt(texto1.getText());
numero2 = Integer.parseInt(texto2.getText());soma = numero1 - numero2;exibir.setVisible(true);
exibir.setText("A SUBTRAÇÃO É: "+soma);}});
exibir.setVisible(false);

//COMANDOS VOLTAR
voltar = new JButton("Voltar");
voltar.setBounds(50,200,100,20);
voltar.addActionListener(
new ActionListener(){
public void actionPerformed(ActionEvent e) {
quintajanela.dispose();}});
tela4.add(voltar); 

//COMANDOS LIMPAR
limpar = new JButton("Limpar");
limpar.setBounds(50,225,100,20);
limpar.addActionListener( new ActionListener(){
public void actionPerformed(ActionEvent e) {
texto1.setText(null);
texto2.setText(null);
exibir.setText(null);
texto1.requestFocus();}});
tela4.add(limpar);

//COMANDOS SAIR
sair = new JButton("Sair");
sair.setBounds(50,250,100,20);
sair.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
int opcao;
Object[]botoes={"Sim","Não"};
opcao=JOptionPane.showOptionDialog(null,"Deseja mesmo fechar a janela?","Fechar",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,botoes,botoes[0]);
if(opcao==JOptionPane.YES_OPTION)System.exit(0);}});

TBsair tsair = new TBsair();
sair.addActionListener(tsair);
tela4.add(sair);

//ADICIONANDO TELAS
tela4.add(rotulo1);
tela4.add(rotulo2);
tela4.add(texto1);
tela4.add(texto2);
tela4.add(exibir);
tela4.add(somar2n);
tela4.add(mensagem);

setSize(400,400);
setLocationRelativeTo(null);}}

//CLASSE SSOBRE MIM - COMANDOS 
class Sobremim extends JDialog{

JLabel form, rotulo1, rot2, sala, nome, dt, sl;
JButton sair, voltar;

public Sobremim (Frame owner, String title,boolean modal){
super(owner,title,modal);
Container tela5 = getContentPane();
tela5.setLayout(null);
ImageIcon icone = new ImageIcon("img/iconesobremim.png");
setIconImage(icone.getImage());

// JLABEL
form = new JLabel ("INFORMAÇÕES PESSOAIS :)");
rotulo1 = new JLabel("NOME:");
rot2 = new JLabel("DATA DA ENTREGA:");
sala = new JLabel("SALA:");
nome = new JLabel("GIOVANA MARSIGLI RODRIGUES");
dt = new JLabel("29/06/2023");
sl = new JLabel("2°DS AMS - TARDE");
rotulo1.setBounds(50,100,1000,20);
form.setBounds(100,40,1000,20);
rot2.setBounds(50,125,1000,20);
sala.setBounds(50,150,1000,20);
nome.setBounds(95,100,1000,20);
dt.setBounds(170,125,1000,20);
sl.setBounds(90,150,1000,20);
//BACKGROUND COLOR - COR DE FUNDO
tela5.setBackground(new Color(255, 243, 244));

//CORES DE FONTES
rotulo1.setForeground(Color.red);
form.setForeground(Color.red);
rot2.setForeground(Color.red);
sala.setForeground(Color.red);
    
Font fonteOriginal = form.getFont();
Font fonteAumentada = fonteOriginal.deriveFont(fonteOriginal.getSize() + 2.0f);
form.setFont(fonteAumentada);

//COMANDOS VOLTAR
voltar = new JButton("Voltar");
voltar.setBounds(50,200,100,20);
voltar.addActionListener(
new ActionListener(){
public void actionPerformed(ActionEvent e) {
sextajanela.dispose();}});
tela5.add(voltar); 

//COMANDOS SAIR
sair = new JButton("Sair");
sair.setBounds(50,225,100,20);
sair.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
int opcao;
Object[]botoes={"Sim","Não"};
opcao=JOptionPane.showOptionDialog(null,"Deseja mesmo fechar a janela?","Fechar",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,botoes,botoes[0]);
if(opcao==JOptionPane.YES_OPTION)System.exit(0);}});

TBsair tsair = new TBsair();
sair.addActionListener(tsair);
tela5.add(sair);
//ADICIONANDO TELAS
tela5.add(rotulo1);
tela5.add(rot2);
tela5.add(form);
tela5.add(sala);
tela5.add(nome);
tela5.add(dt);
tela5.add(sl);

setSize(400,400);
setLocationRelativeTo(null);}}}


class TBsair implements ActionListener{
    public void actionPerformed(ActionEvent evento){
      }
    }
