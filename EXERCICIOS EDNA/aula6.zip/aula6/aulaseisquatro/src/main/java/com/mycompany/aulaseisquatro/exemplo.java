/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aulaseisquatro;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author giova
 */
public class exemplo extends JFrame{
JButton copiar,limpar;
JLabel rotulo1,rotulo2;
JTextField texto1,texto2;
public exemplo(){
Container tela=getContentPane();
tela.setLayout(null);  
rotulo1 = new JLabel("Nome: ");
rotulo2 = new JLabel("Nome: ");
texto1 = new JTextField(20);
texto2 = new JTextField(20);
copiar=new JButton("Copiar");
limpar=new JButton("Limpar");
rotulo1.setBounds(20,30,50,20);
rotulo2.setBounds(20,60,50,20);
texto1.setBounds(60,30,180,20);
texto2.setBounds(60,60,180,20);
copiar.setBounds(20,130,100,20);
limpar.setBounds(180,130,100,20);
copiar.addActionListener(new ActionListener(){
    public void actionPerformed(ActionEvent e){
    texto2.setText(texto1.getText().toUpperCase());}});
limpar.addActionListener(new ActionListener(){
    public void actionPerformed(ActionEvent e){
        texto1.setText("");
        texto2.setText("");
        texto1.requestFocus();}});
tela.add(rotulo1);
tela.add(rotulo2);
tela.add(texto1);
tela.add(texto2);
tela.add(copiar);
tela.add(limpar);
setSize(300,200);
setVisible(true);
setLocationRelativeTo(null);
  setExtendedState(MAXIMIZED_BOTH);
}
public static void main (String args[]){
           exemplo app = new exemplo();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

