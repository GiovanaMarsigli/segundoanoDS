/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aulaseis;

import java.awt.Color;
import java.awt.Container;
import static java.awt.SystemColor.info;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

/**
 *
 * @author Admin
 */
public class exemplo extends JFrame{
    JButton botao1, botao2, botao3;
    //AULA 6 - COM ATRIBUTOS 14,14.1,15,15.1,15.2 
    public exemplo(){
    super("EXEMPLO AULA SEIS");
    Container tela = getContentPane();
    ImageIcon icone = new ImageIcon("hello.png");
    setIconImage(icone.getImage());
    setLayout(null);
    botao1=new JButton("Olá");
    botao2=new JButton("Sair");
    botao3=new JButton("Sair");
    botao1.setBounds(100,50,100,20);
    botao2.setBounds(50,100,100,20);
    botao3.setBounds(150,100,100,20);
    botao1.setToolTipText("Botão usado para abrir algo");
    botao2.setToolTipText("Botão que será usado para sair");
    UIManager.put("ToolTip.foreground",Color.blue);
    tela.add(botao1);
    tela.add(botao2);tela.add(botao3);
    botao2.addActionListener(
    new ActionListener(){
    public void actionPerformed(ActionEvent e){
    int opcao;
    opcao=JOptionPane.showConfirmDialog(null,
    "Deseja mesmo fechar a janela?",
    "Fechar",JOptionPane.YES_NO_OPTION);
    if(opcao==JOptionPane.YES_OPTION)
    System.exit(0);}});
    botao3.addActionListener(
    new ActionListener(){
    public void actionPerformed(ActionEvent e){
    int opcao;
    Object[]botoes={"Sim","Não"};
    opcao=JOptionPane.showOptionDialog(null,"Deseja mesm fechar a janela?",
    "Fechar",JOptionPane.YES_NO_OPTION,
    JOptionPane.QUESTION_MESSAGE,null,
    botoes,botoes[0]);
    if(opcao==JOptionPane.YES_OPTION)
    System.exit(0);}});
    setSize(300,200);
    setVisible(true);
    setLocationRelativeTo(null);}

    
    public static void main(String args[]){
        exemplo app = new exemplo();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
}}


