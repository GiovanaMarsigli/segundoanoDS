/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aulaseisdois;

import javax.swing.JOptionPane;

/**
 *
 * @author giova
 */
public class exemplo {
public static void main(String args[]){ 
Object linguagens[]={"Java","Delphi","C++","VisualBasic"};
Object opcao=JOptionPane.showInputDialog(null,"Qual sua linguagem favorita? ","Enquete",JOptionPane.QUESTION_MESSAGE,null,linguagens,linguagens[0]);
JOptionPane.showMessageDialog(null,"Você escolheu:"+opcao);
System.exit(0);
}   
}
// AULA SEIS 15.4