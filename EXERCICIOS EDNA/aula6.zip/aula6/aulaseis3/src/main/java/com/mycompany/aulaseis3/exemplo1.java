/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aulaseis3;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author giova
 */
//AULA 6 NUMERO 15.5
    public class exemplo1 extends JFrame{
JButton erro,informacao,exclamacao,pergunta,nenhum;  
public exemplo1(){
   super("EXEMPLO AULA SEIS PARTE TRES");   
    Container tela = getContentPane();
    tela.setLayout(null);
    erro=new JButton("Erro");
    informacao=new JButton("Informação");
    exclamacao=new JButton("Exclamação");
    pergunta=new JButton("Pergunta");
    nenhum=new JButton("Nenhum");
    erro.setBounds(30,20,100,20);
    informacao.setBounds(30,50,100,20);
    exclamacao.setBounds(30,80,150,20);
    pergunta.setBounds(30,110,100,20);
    nenhum.setBounds(30,140,100,20);
    tela.add(erro);
    tela.add(informacao);
    tela.add(exclamacao);
    tela.add(pergunta);
    tela.add(nenhum);
    erro.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            JOptionPane.showMessageDialog(null,"Você escolheu erro","Mensagemde Erro",
            JOptionPane.ERROR_MESSAGE,null);}});
    informacao.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            JOptionPane.showMessageDialog(null,"Você escolheu informação","Mensagemde de Informação",
            JOptionPane.INFORMATION_MESSAGE,null);}});
    exclamacao.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            JOptionPane.showMessageDialog(null,"Você escolheu exclamação","Mensagem de Exclamação",
            JOptionPane.WARNING_MESSAGE,null);}});
    pergunta.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            JOptionPane.showMessageDialog(null,"Você escolheu pergunta","Mensagem de Pergunta",
            JOptionPane.QUESTION_MESSAGE,null);}});
    nenhum.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){  
            JOptionPane.showMessageDialog(null,"Você escolheu nenhum","Mensagem",
            JOptionPane.PLAIN_MESSAGE,null);}});      
  setSize(300,200);
  setVisible(true);
  setExtendedState(MAXIMIZED_BOTH);
}
public static void main (String args[]){
           exemplo1 app = new exemplo1();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}



