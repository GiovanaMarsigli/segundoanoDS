/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calculadorabasica;

import javax.swing.JOptionPane;

/**
 *
 * @author dti
 */
public class Principal {

      public static void main(String [] args){
          
        Calculadora Calculadora = new Calculadora(); 
            double n1, n2;
            int op; 
            
            do{
           
            op = Integer.parseInt(JOptionPane.showInputDialog("Digite: \n1 - Somar" +
                    "\n2 - Subtrair \n3 - Multiplicar \n4 - Dividir"));
        switch(op){
            case 1:
              Calculadora.soma();
                break;
            case 2: 
                n1= Double.parseDouble(JOptionPane.showInputDialog("Informe o primeiro número:"));
                n2= Double.parseDouble(JOptionPane.showInputDialog("Informe o segundo número:"));
                Calculadora.sub(n1,n2); 
                break;
            case 3:
                JOptionPane.showMessageDialog(null," A resposta final será de: "+Calculadora.mul());
                break;
            case 4:
                n1= Double.parseDouble(JOptionPane.showInputDialog("Informe o primeiro número:"));
                n2= Double.parseDouble(JOptionPane.showInputDialog("Informe o segundo número:"));
                JOptionPane.showMessageDialog(null," A resposta final será de: "+Calculadora.divi(n1, n2));
                break;
                
            case 0:
                JOptionPane.showMessageDialog(null, "finalizando programa :)");
                break;
            default:
                JOptionPane.showMessageDialog(null, "opção invalida :(");
        }
        }while (op != 0); 
        
    }
}
      

