/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calculadorabasica;

import javax.swing.JOptionPane;

/**
 *
 * @author dti
 */
public class Calculadora {
    
    private double n1;
    private double n2;
    private double r;

   public Calculadora(){
       this(0,0,0);
   }

    public Calculadora(double n1, double n2, double r) {
        this.n1 = n1;
        this.n2 = n2;
        this.r = r;
    }


    /**
     * @return the n1
     */
    public double getN1() {
        return n1;
    }

    /**
     * @param n1 the n1 to set
     */
    public void setN1(double n1) {
        this.n1 = n1;
    }

    /**
     * @return the n2
     */
    public double getN2() {
        return n2;
    }

    /**
     * @param n2 the n2 to set
     */
    public void setN2(double n2) {
        this.n2 = n2;
    }

    /**
     * @return the r
     */
    public double getR() {
        return r;
    }

    /**
     * @param r the r to set
     */
    public void setR(double r) {
        this.r = r;
    }
    
public void soma(){
setN1( Double.parseDouble(JOptionPane.showInputDialog("Informe o primeiro número:")));
setN2( Double.parseDouble(JOptionPane.showInputDialog("Informe o segundo número:")));
setR(getN1()+getN2());
JOptionPane.showMessageDialog(null," A resposta final será de: "+getR());

}
public void sub(double a, double b){
    
this.setR(a-b);
JOptionPane.showMessageDialog(null," A resposta final será de: "+getR());

}

public double mul(){
setN1(Double.parseDouble(JOptionPane.showInputDialog("Informe o primeiro número:")));
setN2(Double.parseDouble(JOptionPane.showInputDialog("Informe o segundo número:")));
setR(getN1()*getN2());
return getR();

}

public double divi(double a, double b){
this.setR(a/b);
return getR(); 
}
}  

