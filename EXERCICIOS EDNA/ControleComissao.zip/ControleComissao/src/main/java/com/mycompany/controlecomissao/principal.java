/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.controlecomissao;

import javax.swing.JOptionPane;

/**
 *
 * @author Admin
 */
public class principal {
    public static void main(String [] args){
          
        vendendor s = new vendendor();
        double valor = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor vendido"));
        
        JOptionPane.showMessageDialog(null, "O resultado sera de "+s.Comissão(valor));       
}
}             