/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.custosviagem;

import java.util.Scanner;



/**
 *
 * @author giova
 */
public class Principal {
         public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int opcao = 0;
        Percurso percurso = new Percurso();
        Custos custos = new Custos();

        while (opcao != 4) {
            System.out.println("Selecione uma opção:");
            System.out.println("1 - Cadastrar dados da viagem");
            System.out.println("2 - Apresentar dados da viagem");
            System.out.println("3 - Apresentar custo total da viagem");
            System.out.println("4 - Sair");
            opcao = input.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Digite os KM percorridos: ");
                    double kmPercorrida = input.nextDouble();
                    System.out.println("Digite o valor do combustível: ");
                    double valorCombustivel = input.nextDouble();
                    System.out.println("Digite o valor do pedágio: ");
                    double valorPedagio = input.nextDouble();
                    percurso.cadastrarPercurso(kmPercorrida, valorCombustivel, valorPedagio);
                    break;
                case 2:
                    percurso.listarPercurso();
                    break;
                case 3:
                    custos.calcularViagem(percurso);
                    break;
                case 4:
                    System.out.println("Obrigada(o) por escolher nosso programa, até breve :)");
                    break;
                default:
                    System.out.println("Opção inválida :(");
            }
        }

        input.close();
    }
}