/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.custosviagem;


/**
 *
 * @author giova
 */
public class Percurso {
   
    private double kmPercorrida;
  private double valorCombustivel;
  private double valorPedagio;

  public void cadastrarPercurso(double kmPercorrida, double valorCombustivel, double valorPedagio) {
    this.kmPercorrida = kmPercorrida;
    this.valorCombustivel = valorCombustivel;
    this.valorPedagio = valorPedagio;
  }

  public void listarPercurso() {
    System.out.println("Km percorrida: " + this.kmPercorrida);
    System.out.println("Valor do combustível: " + this.valorCombustivel);
    System.out.println("Valor do pedágio: " + this.valorPedagio);
  }

  public double getKmPercorrida() {
    return kmPercorrida;
  }

  public double getValorCombustivel() {
    return valorCombustivel;
  }

  public double getValorPedagio() {
    return valorPedagio;
  }
}