/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.custosviagem;

/**
 *
 * @author giova
 */
public class Custos {
    private double totalPercurso;

  public void calcularViagem(Percurso p) {
    double custoCombustivel = p.getKmPercorrida() * p.getValorCombustivel();
    double custoPedagio = p.getValorPedagio();
    double totalCusto = custoCombustivel + custoPedagio;
    this.totalPercurso += totalCusto;
    System.out.println("Custo do combustível: " + custoCombustivel);
    System.out.println("Custo do pedágio: " + custoPedagio);
    System.out.println("Custo total: " + totalCusto);
  }

  public double getTotalPercurso() {
    return totalPercurso;
  }
}