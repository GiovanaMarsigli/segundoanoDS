/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import conexao.Conexao;
import java.awt.Color;
import java.awt.Container;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.*;
import java.text.*;
import javax.swing.*;
import javax.swing.text.MaskFormatter;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;


/**
 *
 * @author giova
 */
class PetPrincipal extends JFrame{
    Conexao con_cliente;
    JLabel rRegistro, rNome, rEspecie, rRaca, rCorPredo, rNasc, rSexo, rPesquisa, background;
    JTextField tRegistro, tNome, tEspecie, tRaca, tCorPredo, tSexo, campoPesquisa;
    JFormattedTextField tNasc;
    JButton   btnSair,prim, ante, prox, ulti, nvreg, grav, alt, exc, limp, btnPesquisar;
    MaskFormatter nNasc;
    JTable tblClientes; //datagrid
    JScrollPane scp_tabela;// container para o datagrid
    
    
    
    public PetPrincipal(){
       
        Container tela = getContentPane();
        tela.setLayout(null);
        setTitle("Tabela PetLovers");
        setResizable(false);
        
        ImageIcon icon = new ImageIcon("img/logo.png");  // Replace with the actual path to your icon image
        Image image = icon.getImage();

        // Set the icon for the JFrame
        setIconImage(image);

        ImageIcon backgroundIcon = new ImageIcon("img/telaprincipal.png"); // Substitua pelo caminho real da sua imagem
        background = new JLabel(backgroundIcon);
        background.setBounds(0, 0, 800, 600); // Defina as dimensões conforme o tamanho da sua janela


        //JBUTTON
        prim = new JButton("Primeiro");
        ante = new JButton("Anterior");
        prox = new JButton("Próximo");
        ulti = new JButton("Ultimo");
        
        nvreg = new JButton("Nova Registro");
        grav = new JButton("Gravar");
        alt = new JButton("Alterar");
        exc = new JButton("Excluir");
        limp = new JButton("Limpar");
        
        btnPesquisar = new JButton("Pesquisar");
        btnSair = new JButton("Sair");
        
         Color pastelOrange = new Color (230, 150, 116); // RGB values for pastel orange

        prim.setBackground(pastelOrange);
        ante.setBackground(pastelOrange);
        prox.setBackground(pastelOrange);
        ulti.setBackground(pastelOrange);
        nvreg.setBackground(pastelOrange);
        grav.setBackground(pastelOrange);
        alt.setBackground(pastelOrange);
        exc.setBackground(pastelOrange);
        limp.setBackground(pastelOrange);
        btnPesquisar.setBackground(pastelOrange);
        btnSair.setBackground(pastelOrange);
        
         //JLABEL
        rRegistro = new JLabel("Registro:");
        rNome = new JLabel("Nome do Pet:");
        rEspecie = new JLabel("Espécie:");
        rRaca = new JLabel("Raça:");
        rCorPredo = new JLabel("Cor Predominante:");
        rNasc = new JLabel("Nascimento:");
        rSexo = new JLabel("Sexo:");
        rPesquisa = new JLabel("Pesquisar Cliente:");
        
        //JTEXTFIELD
        tRegistro = new JTextField(30);
        tNome = new JTextField(60);
        tEspecie = new JTextField(75);
        tRaca = new JTextField(75);
        tCorPredo = new JTextField(75);
        tSexo = new JTextField(75);
        campoPesquisa = new JTextField();
        
        //JFORMATTEDTEXTFILED
        tNasc = new JFormattedTextField(nNasc);
        
        //?
        con_cliente = new Conexao();
        con_cliente.conecta();
        
         //configuraÃ§Ã£o da Jtable
        tblClientes = new javax.swing.JTable();
        scp_tabela = new javax.swing.JScrollPane();
        
        //SETBOUNDS
        rNome.setBounds        (50,55,100,20);
        rRegistro.setBounds    (50,25,100,20);
        rEspecie.setBounds     (50,85,100,20);
        rRaca.setBounds        (50,115,100,20);
        rCorPredo.setBounds    (370,25,400,20);
        rNasc.setBounds        (370,55,100,20);
        rSexo.setBounds        (50,145,100,20);
        tNome.setBounds        (135,55,200,20);
        tRegistro.setBounds    (135,25,200,20);
        tEspecie.setBounds     (135,85,200,20);
        tRaca.setBounds        (135,115,200,20);
        tCorPredo.setBounds    (480,25,200,20);
        tSexo.setBounds        (135,145,200,20);
        tblClientes.setBounds  (50,320,550,200);
        scp_tabela.setBounds   (50,320,550,200);
        prim.setBounds         (50,210,85,20);
        prox.setBounds         (218,210,85,20);
        ante.setBounds         (135,210,85,20);
        ulti.setBounds         (300,210,85,20);
        tNasc.setBounds        (480,55,100,20);
        nvreg.setBounds        (400,210,119,20);
        grav.setBounds         (513,210,85,20);
        alt.setBounds          (595,210,85,20);
        exc.setBounds          (679,210,85,20);
        limp.setBounds         (679,235,85,20);
        rPesquisa.setBounds    (50,530,120,20);
        campoPesquisa.setBounds(180,530,200,20);
        btnPesquisar.setBounds (390,530,100,20);
        btnSair.setBounds      (679, 260, 85, 20);
        
        //MASKFORMATTER
        try{
            nNasc = new MaskFormatter("##/##/####");
            nNasc.setPlaceholderCharacter('_');
        }catch(ParseException excp){}
        
        //FUNÇÕES
        //PROXIMO
        prox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    if (con_cliente.resultset.isLast()) {
                        JOptionPane.showMessageDialog(null, "Você já esta no ultimo registro:(");
                    } else {
                        con_cliente.resultset.next();
                        mostrar_Dados();
                    }
                } catch (SQLException erro) {
                    JOptionPane.showMessageDialog(null, "Desculpe, não conseguimos acessar o primeiro registro! " + erro, "Mensagem do programa", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
                //PRIMEIRO
        prim.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                   try{  
                    con_cliente.resultset.first();
                        mostrar_Dados();
                    }catch(SQLException erro){
                        JOptionPane.showMessageDialog(null, "Não foi possí­vel acessar o primeiro registro");
                    }
                }});
        
        //ANTERIOR
        ante.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    if (con_cliente.resultset.isFirst()) {
                        JOptionPane.showMessageDialog(null, "Você já esta no primeiro registro:(");
                    } else {
                        con_cliente.resultset.previous();
                        mostrar_Dados();
                    }
                } catch (SQLException erro) {
                    JOptionPane.showMessageDialog(null, "Desculpe, não conseguimos acessar o primeiro registro! " + erro, "Mensagem do programa", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        
        //ULTIMO
        ulti.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                 try{
                        con_cliente.resultset.last();
                        mostrar_Dados();
                    }catch(SQLException erro){
                        JOptionPane.showMessageDialog(null, "Não foi possí­vel acessar o primeiro registro");
                    }
                }});
        //LIMPAR
        limp.addActionListener(new ActionListener() 
            {
               public void actionPerformed(ActionEvent e) {
        // Limpar os campos de texto e formatados
        tRegistro.setText("");
        tNome.setText("");
        tEspecie.setText("");
        tRaca.setText("");
        tCorPredo.setText("");
        tSexo.setText("");
        tNasc.setText("");
    }
     });
        nvreg.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tRegistro.setText("");
                tCorPredo.setText("");
                tEspecie.setText("");
                tNome.setText("");
                tRaca.setText("");
                tSexo.setText("");
                tNasc.setText("");
            }
        });
         //GRAVAR
       grav.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
                String nome = tNome.getText();
                String especie = tEspecie.getText();
                String raca = tRaca.getText();
                String corPredo = tCorPredo.getText();
                String sexo = tSexo.getText();
                String dataNasc = tNasc.getText();
        
        try {
            String insert_sql = "INSERT INTO tabelapet (nome_pet, especie, raca, cor_predo, nascimento, sexo) VALUES ('" + nome + "', '" + especie + "', '" + raca + "', '" + corPredo + "', '" + dataNasc + "', '" + sexo + "')";
            con_cliente.statement.executeUpdate(insert_sql);
            JOptionPane.showMessageDialog(null, "Gravação realizada com sucesso!!", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);

            con_cliente.executaSQL("select * from tabelapet order by num_registro");
            preencherTabela();
        } catch (SQLException errosql) {
            JOptionPane.showMessageDialog(null, "\n Erro na gravação: \n" + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }
    }
});
                        //ALTERAR
alt.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
                String nome = tNome.getText();
                String especie = tEspecie.getText();
                String raca = tRaca.getText();
                String corPredo = tCorPredo.getText();
                String sexo = tSexo.getText();
                String dataNasc = tNasc.getText();
        String sql = null;
        String msg = "";
        try {
            if (tRegistro.getText().equals("")) {
            String insert_sql = "INSERT INTO tabelapet (nome_pet, especie, raca, cor_predo, nascimento, sexo) VALUES ('" + nome + "', '" + especie + "', '" + raca + "', '" + corPredo + "', '" + dataNasc + "', '" + sexo + "')";
                msg = "Gravação de um novo registro";
            } else {
                sql = "update tabelapet set nome_pet='" + nome + "', especie='" + especie + "', raca='" + raca
                            + "', cor_predo='" + corPredo  + "', nascimento='" + dataNasc + "', sexo='" + sexo + "' where num_registro=" + tRegistro.getText();
                msg = "Alteração de registro";
            }
            con_cliente.statement.executeUpdate(sql);
            // Removido daqui: JOptionPane.showMessageDialog(...), con_cliente.executaSQL(...), preencherTabela();
        } catch (SQLException errosql) {
            JOptionPane.showMessageDialog(null, "\n Erro na gravação: \n" + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            return; // Sair da função em caso de erro
        }
        
        // Movido para fora do bloco try-catch
        JOptionPane.showMessageDialog(null, msg, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        con_cliente.executaSQL("select * from tabelapet order by num_registro");
        preencherTabela();
    }
});
 //EXCLUIR
        
exc.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        String sql = "";
        try {
            int resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja excluir o registro?", "Confirmar Exclusão", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            
            if (resposta == JOptionPane.YES_OPTION) {
                sql = "DELETE FROM tabelapet WHERE num_registro = " + tRegistro.getText();
                int excluir = con_cliente.statement.executeUpdate(sql);

                if (excluir == 1) {
                    JOptionPane.showMessageDialog(null, "Exclusão realizada com sucesso!!", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
                    con_cliente.executaSQL("SELECT * FROM tabelapet ORDER BY num_registro");
                    con_cliente.resultset.first();
                    preencherTabela();
                    posicionarRegistro();
                }
            } else {
                JOptionPane.showMessageDialog(null, "Operação cancelada pelo usuário!!", "Mensagem do programa", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException errosql) {
            JOptionPane.showMessageDialog(null, "Erro na exclusão: " + errosql, "Mensagem do Programa", JOptionPane.ERROR_MESSAGE);
        }
    }
});
        //PESQUISAR
        btnPesquisar.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        try {
        String pesquisa = "select * from tabelapet where especie like '" + campoPesquisa.getText() + "%'";
        con_cliente.executaSQL(pesquisa);
        
        if(con_cliente.resultset.first()){
            preencherTabela();
        }else{
            JOptionPane.showMessageDialog(null,"\n Não existe dados com este parametro!!","Mensagem do Programa",JOptionPane.INFORMATION_MESSAGE);
        }
        
        } catch (SQLException errosql) {
            JOptionPane.showMessageDialog(null, "\n Os dados digitados não foram localizados!! :\n"+errosql,"Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }
    }
});
        
        //SAIR
         btnSair.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Ação a ser executada quando o botão Sair for clicado
                System.exit(0); // Encerrar o programa
            }
        });

       //TELAADD
        tela.add(background);
        background.add(rRegistro);
        background.add(rNome);
        background.add(rEspecie);
        background.add(rRaca);
        background.add(rNasc);
        background.add(rCorPredo);
        background.add(rSexo);
        background.add(tRegistro);
        background.add(tNome);
        background.add(tEspecie);
        background.add(tRaca);
        background.add(tNasc);
        background.add(tCorPredo);
        background.add(tSexo);
        background.add(prim);
        background.add(prox);
        background.add(ante);
        background.add(ulti);
        background.add(nvreg);
        background.add(grav);
        background.add(tblClientes);
        background.add(scp_tabela);
        background.add(alt);
        background.add(exc);
        background.add(limp);
        background.add(rPesquisa);
        background.add(campoPesquisa);
        background.add(btnPesquisar);
        background.add(btnSair);
        
 
         //DESIGN TABELA
tblClientes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
tblClientes.setFont(new java.awt.Font("Arial", 1, 12));
tblClientes.setModel(new javax.swing.table.DefaultTableModel(
        new Object[][]{
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null}
        },
        new String[]{"Registro", "Nome", "Espécie", "Raça", "Cor Predominate", "Nascimento", "Sexo"}
) {
    boolean[] canEdit = new boolean[]{
        false, false, false, false, false
    };

    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit[columnIndex];
    }
});



tblClientes.setAutoCreateRowSorter(true); // Ativa a classificação ordenada da tabela

scp_tabela.setViewportView(tblClientes);

        //fim da cofiguraÃ§Ã£o da jtable
         //SETS
        setSize(800,600);
        setVisible(true);
        setLocationRelativeTo(null);
        
        con_cliente.executaSQL("select * from tabelapet order by num_registro");
        preencherTabela();
        posicionarRegistro();
        
    }
    public void preencherTabela()
    {
        tblClientes.getColumnModel().getColumn(0).setPreferredWidth(70);
        tblClientes.getColumnModel().getColumn(1).setPreferredWidth(100);
        tblClientes.getColumnModel().getColumn(2).setPreferredWidth(70);
        tblClientes.getColumnModel().getColumn(3).setPreferredWidth(100);
        tblClientes.getColumnModel().getColumn(4).setPreferredWidth(100);
        tblClientes.getColumnModel().getColumn(5).setPreferredWidth(100);
        tblClientes.getColumnModel().getColumn(6).setPreferredWidth(100);

        DefaultTableModel modelo = (DefaultTableModel) tblClientes.getModel();
        modelo.setNumRows(0);
        
     try {
            con_cliente.resultset.beforeFirst();
            while (con_cliente.resultset.next()) {
                modelo.addRow(new Object[]{
                    con_cliente.resultset.getString("num_registro"),
                    con_cliente.resultset.getString("nome_pet"),
                    con_cliente.resultset.getString("especie"),
                    con_cliente.resultset.getString("raca"),
                    con_cliente.resultset.getString("cor_predo"),
                    con_cliente.resultset.getString("nascimento"),
                    con_cliente.resultset.getString("sexo"),});
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "erro ao listar dados da tabela!! \n " + erro, "Mensagem do programa", JOptionPane.INFORMATION_MESSAGE);
        }

    }
    public void posicionarRegistro()
  {
      try{
          con_cliente.resultset.first(); //posiciona no 1° registro da tabela
          mostrar_Dados(); //chama o metodo que irá¡ bustar o dado da tabela
      }catch(SQLException erro){
          JOptionPane.showMessageDialog(null, "Não foi possi­vel posicionar no primeiro registro: "+erro,"Mensagem do Programa",JOptionPane.INFORMATION_MESSAGE);
      }
  }
public void mostrar_Dados()
  {
      try{
         tRegistro.setText(con_cliente.resultset.getString("num_registro"));
            tNome.setText(con_cliente.resultset.getString("nome_pet"));
            tEspecie.setText(con_cliente.resultset.getString("especie"));
            tRaca.setText(con_cliente.resultset.getString("raca"));
            tCorPredo.setText(con_cliente.resultset.getString("cor_predo"));
            tNasc.setText(con_cliente.resultset.getString("nascimento"));
            tSexo.setText(con_cliente.resultset.getString("sexo")); 
      }catch(SQLException erro){
          JOptionPane.showMessageDialog(null, "Não localizou dados: "+erro,"Mensagem do Programa",JOptionPane.INFORMATION_MESSAGE);
      }
  }
  public static void main(String args[])
        {
            PetPrincipal app = new PetPrincipal();
            app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
} 

