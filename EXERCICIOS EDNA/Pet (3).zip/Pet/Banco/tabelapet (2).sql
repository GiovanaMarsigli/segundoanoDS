-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30-Nov-2023 às 18:36
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `tabelapet`
--
create DATABASE `tabelapet`;
use `tabelapet`;
-- --------------------------------------------------------

--
-- Estrutura da tabela `tabelapet`
--

CREATE TABLE `tabelapet` (
  `num_registro` int(11) NOT NULL,
  `nome_pet` varchar(25) NOT NULL,
  `especie` varchar(25) NOT NULL,
  `raca` varchar(25) NOT NULL,
  `cor_predo` varchar(20) NOT NULL,
  `nascimento` varchar(10) NOT NULL,
  `sexo` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `tabelapet`
--

INSERT INTO `tabelapet` (`num_registro`, `nome_pet`, `especie`, `raca`, `cor_predo`, `nascimento`, `sexo`) VALUES
(1, 'Pipoca', 'Cão', 'Vira-lata', 'Preta', '2016-07-18', 'Macho'),
(2, 'Natashuda', 'Peixe', 'Telescópio', 'Laranja', '2022-02-14', 'Femea'),
(3, 'Angelina', 'Gato', 'Ragdoll', 'Branco', '2020-08-13', 'Femea');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tabelapet`
--
ALTER TABLE `tabelapet`
  ADD PRIMARY KEY (`num_registro`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tabelapet`
--
ALTER TABLE `tabelapet`
  MODIFY `num_registro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
