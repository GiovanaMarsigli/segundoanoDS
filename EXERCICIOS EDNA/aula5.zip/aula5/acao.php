<html>
<head>
<title>Documento acao.php</title>
</head>
<body>
oi
<?php echo $_POST["nome"];?>
. Você tem
<?php echo $_POST["idade"];?>
 anos.
</body>
</html>