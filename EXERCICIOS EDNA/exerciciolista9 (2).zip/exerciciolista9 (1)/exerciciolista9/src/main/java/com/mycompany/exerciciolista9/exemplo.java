/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exerciciolista9;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/**
 *
 * @author dti
 */
public class exemplo extends JFrame{
JButton enviar, limpar;
JLabel  rotulo1, rotulo2, rotulo3, rotulo4, rotulo5, rotulo6, instrucao, instrucao1, instrucao2;
JTextField texto1,texto2;
JRadioButton primeira, segunda; 
JCheckBox prim, seg, ter;
JComboBox lista;
String estadocivil[] = {"Solteiro(a)", "Casado(a)", "Separado(a)", "Divorciado(a)", "Viúvo(a)"};
 
public exemplo(){
super("Dados Pessoais");
ImageIcon icone = new ImageIcon("sapo.jpg");
setIconImage(icone.getImage());
Container tela = getContentPane();
tela.setLayout(null);

//inicializando rotulos
rotulo1 = new JLabel("Nome: ");
rotulo2 = new JLabel("Idade: ");
rotulo3 = new JLabel ("Sexo:");
rotulo4 = new JLabel ("Interesses: ");
rotulo5 = new JLabel ("Estado civil: ");
rotulo6 = new JLabel("Giovana Marsigli Rodrigues 2° DS AMS");
instrucao = new JLabel ("INSTRUÇÕES DE ATALHO");
instrucao1= new JLabel ("Ao clicar em alt+E será habilitado a opção 'ENVIAR'");
instrucao2= new JLabel ("Ao clicar em alt+L será habilitado a opção 'LIMPAR'");

//add cor ao nome do aluno
rotulo6.setForeground(Color.RED); 
instrucao.setForeground(Color.RED); 

//textfiels tam 20
texto1 = new JTextField(20);
texto2 = new JTextField(20);

//botões
enviar=new JButton("ENVIAR");
limpar=new JButton("LIMPAR");

//adicionando opções de escolha
primeira = new JRadioButton("Masculino");
segunda = new JRadioButton("Feminino");

//adcionando opções de interesses
prim = new JCheckBox ("Automveis");
seg= new JCheckBox ("Barcos");
ter = new JCheckBox ("Aviões");

  
//adcionando combobox
lista = new JComboBox(estadocivil);

//add setmaximum
lista.setMaximumRowCount(5);

//setbounds
rotulo1.setBounds(20,30,50,20);
rotulo2.setBounds(20,60,50,20);
rotulo3.setBounds(20,90,50,20);
rotulo4.setBounds(20,120,100,20);
rotulo5.setBounds(20,160,100,20);
rotulo6.setBounds(20,240,250,20);
texto1.setBounds(60,30,180,20);
texto2.setBounds(60,60,180,20);
enviar.setBounds(20,200,100,20);
limpar.setBounds(120,200,100,20);
primeira.setBounds(60,90,90,20);
segunda.setBounds(160,90,100,20);
prim.setBounds(100,120,100,20);
seg.setBounds(200,120,100,20);
ter.setBounds(300,120,100,20);
lista.setBounds(100,160,100,20);
instrucao.setBounds(20,260,300,20);
instrucao1.setBounds(20,280,300,20);
instrucao2.setBounds(20,300,300,20);

//adicionando botao limpar
limpar.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        texto1.setText("");
        texto2.setText("");
        texto1.requestFocus();
        lista.setSelectedIndex(-1);
        primeira.setSelected(false);
        segunda.setSelected(false);
        prim.setSelected(false);
        seg.setSelected(false);  
        ter.setSelected(false);
      
    }
});
enviar.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        String nome = texto1.getText();
        String idade = texto2.getText();
        String sexo = primeira.isSelected() ? "Masculino" : "Feminino";
        String interesses = "";
        if (prim.isSelected()) {
            interesses += "Automóveis ";
        }
        if (seg.isSelected()) {
            interesses += "Barcos ";
        }
        if (ter.isSelected()) {
            interesses += "Aviões ";
        }
        String estadoCivil = (String) lista.getSelectedItem();
        String mensagem = "Nome: " + nome + "\nIdade: " + idade + "\nSexo: " + sexo + "\nInteresses: " + interesses + "\nEstado civil: " + estadoCivil;
        JOptionPane.showMessageDialog(null, mensagem);
    }
});

//inserindo atalho
 enviar.setMnemonic(KeyEvent.VK_E);
 limpar.setMnemonic(KeyEvent.VK_L);
 
//adici9onando telas visiveis
tela.add(rotulo1);tela.add(rotulo2);
tela.add(rotulo3);tela.add(rotulo4);
tela.add(rotulo5);tela.add(rotulo6);
tela.add(texto1);tela.add(texto2);
tela.add(enviar);tela.add(limpar);
tela.add(primeira);tela.add(segunda);
tela.add(prim);tela.add(seg);tela.add(ter);
tela.add(lista);tela.add(instrucao);
tela.add(instrucao1); tela.add(instrucao2); 

//definindo tela
setSize(300,200);
setVisible(true);
setLocationRelativeTo(null);
setExtendedState(MAXIMIZED_BOTH);
Color corPersonalizada = new Color(245,245,220);
getContentPane().setBackground(corPersonalizada);
}
    public static void main (String args[]){
exemplo app = new exemplo();
app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}