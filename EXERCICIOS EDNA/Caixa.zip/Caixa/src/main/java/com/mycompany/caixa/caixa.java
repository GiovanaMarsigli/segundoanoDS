/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.caixa;

import javax.swing.JOptionPane;

/**
 *
 * @author dti
 */
public class caixa {
    
    //Atributo
    private double saldo;
    
    //construtores
    //inicializando o atributo zerado
    public caixa() {
        this(0);
    }
    //inicializando o atributo com o parâmetro
    public caixa(double saldo) {
        this.saldo = saldo;
    }
    
  //getter e setter

    /**
     * @return the saldo
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    //Métodos especificos da classe
    
    public void entrar(){
    //Lê um valor, converte de String para double e atribui a variavel valor
    double valor = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor da entrada: "));
    /*Soma o conteudo do atributo saldo com a variavel valor e passa o resultado por parametro, para o metodo setSaldo() */
    this.setSaldo(this.saldo + valor);
    }
    
    public void retirar(){
    //Lê um valor, converte de String para double e atribui a variavel valor
    double valor = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor da retirada:"));
    /* Subtrai o conteudo do atributo saldo com a variavel valor e passa o resultado por parametro para o metodo setSaldo() */
    this.setSaldo(this.saldo - valor);
    }
    
}
