/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.caixa;
import javax.swing.*;//importação da API swing 
/**
 *
 * @author dti
 */
public class principal {
    public static void main(String args []){
        caixa cx1 = new caixa(); //Instanciação do objeto cx1
        int op; //declaração da variavel de opções 
        do{//Incio do looping do-while
            //Apresentacao e leitura do menu de opções
            op = Integer.parseInt(JOptionPane.showInputDialog("Digite: \n1 - Entrada" +
                    "\n2 - Retirada \n3 - Consultar saldo \n0 - Sair"));
        switch (op){//Abertura da estrutura de switch-case
            case 1:
                cx1.entrar(); //Chamada ao método entrar do objeto cx1
                break;
            case 2: 
                cx1.retirar(); //Chamada ao método entrar o objeto cx1
                break;
            case 3:
                //Apresentação do conteudo do atributo saldo
                JOptionPane.showMessageDialog(null, "saldo atual: " + cx1.getSaldo());
                break;
            case 0:
                JOptionPane.showMessageDialog(null, "finalizando programa :)");
                break;
            default:
                JOptionPane.showMessageDialog(null, "opção invalida :(");
        }
        }while (op != 0); //Repetira as operações enquanto a opção for diferente de zero
        
    }
}
        
