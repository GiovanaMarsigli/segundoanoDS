import conexao.Conexao;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;

/**
 *
 * @author giova
 */
 public class FrmTelaCad extends JFrame{
    Conexao con_cliente;
    JLabel rCodigo, rNome, rEmail, rTel, rData, rPesquisa;
    JTextField tcodigo, tnome, temail, campoPesquisa;
    JFormattedTextField tel, data;
    MaskFormatter mTel, mData;
    JTable tblClientes; //datagrid
    JScrollPane scp_tabela; //container para o datagrid
    JButton   btnSair,prim, ante, prox, ulti, nvreg, grav, alt, exc, limp, btnPesquisar;
    public FrmTelaCad()
    {
        Container tela = getContentPane();
        tela.setLayout(null);
        setTitle("Conexão Java com MySql");
        setResizable(false);
        
           getContentPane().setBackground(new Color(255, 255, 153));
        //JBUTTON
        prim = new JButton("Primeiro");
        ante = new JButton("Anterior");
        prox = new JButton("Próximo");
        ulti = new JButton("Ultimo");
        nvreg = new JButton("Nova Registro");
        grav = new JButton("Gravar");
        alt = new JButton("Alterar");
        exc = new JButton("Excluir");
        limp = new JButton("Limpar");
        btnPesquisar = new JButton("Pesquisar");
        btnSair = new JButton("Sair");
        //JLABEL
        rCodigo = new JLabel("Código:");
        rNome = new JLabel("Nome:");
        rEmail = new JLabel("Email:");
        rTel = new JLabel("Telefone:");
        rData = new JLabel("Data:");
        rPesquisa = new JLabel("Pesquisar Cliente:");
        
        //JTEXTFIELD
        tcodigo = new JTextField(3);
        tnome = new JTextField(60);
        temail = new JTextField(75);
        campoPesquisa = new JTextField();
        
        //JFORMATTEDTEXTFILED
        tel = new JFormattedTextField(mTel);
        data = new JFormattedTextField(mData);
        
        //?
        con_cliente = new Conexao();
        con_cliente.conecta();
 
        //configuraÃ§Ã£o da Jtable
        tblClientes = new javax.swing.JTable();
        scp_tabela = new javax.swing.JScrollPane();
        
        //SETBOUNDS
        rNome.setBounds        (50,55,100,20);
        rCodigo.setBounds      (50,25,100,20);
        rTel.setBounds         (50,85,100,20);
        rData.setBounds        (50,115,100,20);
        rEmail.setBounds       (50,145,100,20);
        tcodigo.setBounds      (105,25,50,20);
        tnome.setBounds        (105,55,200,20);
        temail.setBounds       (105,145,200,20);
        tblClientes.setBounds  (50,320,550,200);
        scp_tabela.setBounds   (50,320,550,200);
        prim.setBounds         (50,210,85,20);
        prox.setBounds         (218,210,85,20);
        ante.setBounds         (135,210,85,20);
        ulti.setBounds         (300,210,85,20);
        tel.setBounds          (105,85,100,20);
        data.setBounds         (105,115,100,20);
        nvreg.setBounds        (400,210,119,20);
        grav.setBounds         (513,210,85,20);
        alt.setBounds          (595,210,85,20);
        exc.setBounds          (679,210,85,20);
        limp.setBounds         (679,235,85,20);
        rPesquisa.setBounds    (50,530,120,20);
        campoPesquisa.setBounds(180,530,200,20);
        btnPesquisar.setBounds (390,530,100,20);
        btnSair.setBounds      (679, 260, 85, 20);
        
       //MASKFORMATTER
        try{
            mTel = new MaskFormatter("(##)#####-####");
            mData = new MaskFormatter("##/##/####");
            mTel.setPlaceholderCharacter('_');
            mData.setPlaceholderCharacter('_');
        }catch(ParseException excp){}
        
        //FUNÇÕES
        //PRÓXIMO
        prox.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        try {
            if (con_cliente.resultset.isLast()) {
                con_cliente.resultset.first(); // Vai para o primeiro registro
            } else {
                con_cliente.resultset.next(); // Vai para o próximo registro
            }
            mostrar_Dados();
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Não foi possível acessar o próximo registro", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }}});

        
        //PRIMEIRO
        prim.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                   try{  
                    con_cliente.resultset.first();
                        mostrar_Dados();
                    }catch(SQLException erro){
                        JOptionPane.showMessageDialog(null, "Não foi possí­vel acessar o primeiro registro");
                    }
                }});
        
        //ANTERIOR
        ante.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                try {
              if (con_cliente.resultset.isFirst()) {
                con_cliente.resultset.last(); // Vai para o último registro
            } else {
                con_cliente.resultset.previous(); // Vai para o registro anterior
            }
            mostrar_Dados();
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Não foi possível acessar o registro anterior", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }}});

        
        //ULTIMO
        ulti.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                 try{
                        con_cliente.resultset.last();
                        mostrar_Dados();
                    }catch(SQLException erro){
                        JOptionPane.showMessageDialog(null, "Não foi possí­vel acessar o primeiro registro");
                    }
                }});
        //LIMPAR
        limp.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        // Limpar os campos de texto e formatados
        tcodigo.setText("");
        tnome.setText("");
        temail.setText("");
        tel.setText("");
        data.setText("");
    }
});
        
 //GRAVAR
       grav.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        String nome = tnome.getText();
        String data_nasc = data.getText();
        String telefone = tel.getText();
        String email = temail.getText();
        
        try {
            String insert_sql = "insert into tbclientes (nome, telefone, email, dt_nasc) values ('" + nome + "','" + telefone + "','" + email + "','" + data_nasc + "')";
            con_cliente.statement.executeUpdate(insert_sql);
            JOptionPane.showMessageDialog(null, "Gravação realizada com sucesso!!", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);

            con_cliente.executaSQL("select * from tbclientes order by cod");
            preencherTabela();
        } catch (SQLException errosql) {
            JOptionPane.showMessageDialog(null, "\n Erro na gravação: \n" + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }
    }
});
        //ALTERAR
alt.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        String nome = tnome.getText();
        String data_nasc = data.getText();
        String telefone = tel.getText();
        String email = temail.getText();
        String sql;
        String msg = "";
        try {
            if (tcodigo.getText().equals("")) {
                sql = "insert into tbclientes (nome, telefone, email, dt_nasc) values ('" + nome + "','" + telefone + "','" + email + "','" + data_nasc + "')";
                msg = "Gravação de um novo registro";
            } else {
                sql = "update tbclientes set nome='" + nome + "', telefone='" + telefone + "', email='" + email
                            + "', dt_nasc='" + data_nasc + "' where cod=" + tcodigo.getText();
                msg = "Alteração de registro";
            }
            con_cliente.statement.executeUpdate(sql);
            // Removido daqui: JOptionPane.showMessageDialog(...), con_cliente.executaSQL(...), preencherTabela();
        } catch (SQLException errosql) {
            JOptionPane.showMessageDialog(null, "\n Erro na gravação: \n" + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            return; // Sair da função em caso de erro
        }
        
        // Movido para fora do bloco try-catch
        JOptionPane.showMessageDialog(null, msg, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        con_cliente.executaSQL("select * from tbclientes order by cod");
        preencherTabela();
    }
});

        //EXCLUIR
       exc.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        String sql = "";
        try {
            int resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja excluir o registro?", "Confirmar Exclusão", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (resposta == JOptionPane.YES_OPTION) {
                sql = "delete from tbclientes where cod = " + tcodigo.getText();
                int excluir = con_cliente.statement.executeUpdate(sql);
                if (excluir == 1) {
                    JOptionPane.showMessageDialog(null, "Exclusão realizada com sucesso!", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
                    con_cliente.executaSQL("select * from tbclientes order by cod");
                    con_cliente.resultset.first();
                    preencherTabela();
                    posicionarRegistro();
                }
            } else if (resposta == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(null, "Operação cancelada pelo usuário.", "Mensagem do programa", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException errosql) {
            JOptionPane.showMessageDialog(null, "Erro na exclusão: " + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }
    }
});


        //PESQUISAR
        btnPesquisar.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        try {
        String pesquisa = "select * from tbclientes where nome like '" + campoPesquisa.getText() + "%'";
        con_cliente.executaSQL(pesquisa);
        
        if(con_cliente.resultset.first()){
            preencherTabela();
        }else{
            JOptionPane.showMessageDialog(null,"\n Não existe dados com este parametro!!","Mensagem do Programa",JOptionPane.INFORMATION_MESSAGE);
        }
        
        } catch (SQLException errosql) {
            JOptionPane.showMessageDialog(null, "\n Os dados digitados não foram localizados!! :\n"+errosql,"Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }
    }
});
         btnSair.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Ação a ser executada quando o botão Sair for clicado
                System.exit(0); // Encerrar o programa
            }
        });
        //TELAADD
        tela.add(rCodigo);
        tela.add(rNome);
        tela.add(rEmail);
        tela.add(rTel);
        tela.add(rData);
        tela.add(tcodigo);
        tela.add(tnome);
        tela.add(temail);
        tela.add(tel);
        tela.add(data);
        tela.add(prim);
        tela.add(prox);
        tela.add(ante);
        tela.add(ulti);
        tela.add(nvreg);
        tela.add(grav);
        tela.add(tblClientes);
        tela.add(scp_tabela);
        tela.add(alt);
        tela.add(exc);
        tela.add(limp);
        tela.add(rPesquisa);
        tela.add(campoPesquisa);
        tela.add(btnPesquisar);
        tela.add(btnSair);
        //DESIGN TABELA
        tblClientes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0,0,0)));
        tblClientes.setFont(new java.awt.Font("Arial", 1,12));
        tblClientes.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {null,null,null,null,null},
            {null,null,null,null,null},
            {null,null,null,null,null},
            {null,null,null,null,null}
        },
         new String [] {"Código","Nome","Data Nascimento","Telefone","Email"})
        {
            boolean[] canEdit = new boolean [] {
                false,false,false,false,false};
            
            public boolean isCellEditable(int rowIndex, int columnIndex)
            {
                return canEdit [columnIndex];}
            });
        scp_tabela.setViewportView(tblClientes);
        
        tblClientes.setAutoCreateRowSorter(true); //ativa a classificaÃ§Ã£o ordenada a tabela
        
        //fim da cofiguraÃ§Ã£o da jtable
        
        //SETS
        setSize(800,600);
        setVisible(true);
        setLocationRelativeTo(null);
        
        con_cliente.executaSQL("select * from tbclientes order by cod");
        preencherTabela();
        posicionarRegistro();
        
    }
    public void preencherTabela()
    {
        tblClientes.getColumnModel().getColumn(0).setPreferredWidth(4);
        tblClientes.getColumnModel().getColumn(1).setPreferredWidth(150);
        tblClientes.getColumnModel().getColumn(2).setPreferredWidth(11);
        tblClientes.getColumnModel().getColumn(3).setPreferredWidth(14);
        tblClientes.getColumnModel().getColumn(4).setPreferredWidth(100);
        
        DefaultTableModel modelo = (DefaultTableModel) tblClientes.getModel();
        modelo.setNumRows(0);
        
        try{
            con_cliente.resultset.beforeFirst();
            while(con_cliente.resultset.next()){
                modelo.addRow(new Object[]{
                con_cliente.resultset.getString("cod"),con_cliente.resultset.getString("nome"),con_cliente.resultset.getString("dt_nasc"),con_cliente.resultset.getString("telefone"),con_cliente.resultset.getString("email")
            });
            }
        }catch(SQLException erro){
            JOptionPane.showMessageDialog(null, "\n Erro ao listar dados da tabela!!:\n" +erro,"Mensagem do Programa",JOptionPane.INFORMATION_MESSAGE);
        }
    }
  public void posicionarRegistro()
  {
      try{
          con_cliente.resultset.first(); //posiciona no 1° registro da tabela
          mostrar_Dados(); //chama o metodo que irá¡ bustar o dado da tabela
      }catch(SQLException erro){
          JOptionPane.showMessageDialog(null, "Não foi possi­vel posicionar no primeiro registro: "+erro,"Mensagem do Programa",JOptionPane.INFORMATION_MESSAGE);
      }
  }
  public void mostrar_Dados()
  {
      try{
          tcodigo.setText(con_cliente.resultset.getString("cod")); //Associar a caixa de texto ao campo cod
          tnome.setText(con_cliente.resultset.getString("nome")); //Associar a caixa de texto ao campo nome
          data.setText(con_cliente.resultset.getString("dt_nasc"));//Associar a caixa de texto ao campo data de nascimento
          tel.setText(con_cliente.resultset.getString("telefone"));//Associar a caixa de texto ao campo telefone
          temail.setText(con_cliente.resultset.getString("email"));//Associar a caixa de texto ao campo email
      }catch(SQLException erro){
          JOptionPane.showMessageDialog(null, "NÃ£o localizou dados: "+erro,"Mensagem do Programa",JOptionPane.INFORMATION_MESSAGE);
      }
  }
  public static void main(String args[])
        {
            FrmTelaCad app = new FrmTelaCad();
            app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
} 