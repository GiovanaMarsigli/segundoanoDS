/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.formulariomatricula;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author giova
 */
public class frmMostrar extends javax.swing.JFrame{
      private JPanel painel;
    private JLabel rotuloNome, rotuloMatricula, rotuloRestricao, rotuloPeriodo, rotuloCurso, rotuloSerie;
    private JLabel labelNome, labelMatricula, labelRestricao, labelPeriodo, labelCurso, labelSerie;

    public frmMostrar(String nome, String matricula, String restricao, String periodo, String curso, String serie){
        super("Dados do Aluno");
        Container tela = getContentPane();
        ImageIcon icone = new ImageIcon("usuario.jpg");
        setIconImage(icone.getImage());
        painel = new JPanel();
        painel.setLayout(null);   

        rotuloNome = new JLabel("Nome:");
        rotuloMatricula = new JLabel("Matrícula:");
        rotuloRestricao = new JLabel("Restrições Médicas:");
        rotuloPeriodo = new JLabel("Período:");
        rotuloCurso = new JLabel("Curso:");
        rotuloSerie = new JLabel("Série:");

        labelNome = new JLabel(nome);
        labelMatricula = new JLabel(matricula);
        labelRestricao = new JLabel(restricao);
        labelPeriodo = new JLabel(periodo);
        labelCurso = new JLabel(curso);
        labelSerie = new JLabel(serie);

        rotuloNome.setBounds(20, 20, 100, 20);
        rotuloMatricula.setBounds(20, 50, 100, 20);
        rotuloRestricao.setBounds(20, 80, 150, 20);
        rotuloPeriodo.setBounds(20, 180, 100, 20);
        rotuloCurso.setBounds(20, 210, 100, 20);
        rotuloSerie.setBounds(20, 240, 100, 20);

        labelNome.setBounds(130, 20, 200, 20);
        labelMatricula.setBounds(130, 50, 200, 20);
        labelRestricao.setBounds(20, 110, 400, 50);
        labelPeriodo.setBounds(130, 180, 200, 20);
        labelCurso.setBounds(130, 210, 200, 20);
        labelSerie.setBounds(130, 240, 200, 20);
        
        // Botão Voltar
        JButton voltarButton = new JButton("Voltar");
        voltarButton.setBounds(20, 270, 80, 20);
        voltarButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        Matricula matricula = new Matricula();
        matricula.setVisible(true);
        dispose(); }});

        // Botão Sair
        JButton sairButton = new JButton("Sair");
        sairButton.setBounds(120, 270, 80, 20);
        sairButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        System.exit(0); // Finaliza o projeto
    }
});

        painel.add(rotuloNome);
        painel.add(labelNome);
        painel.add(rotuloMatricula);
        painel.add(labelMatricula);
        painel.add(rotuloRestricao);
        painel.add(labelRestricao);
        painel.add(rotuloPeriodo);
        painel.add(labelPeriodo);
        painel.add(rotuloCurso);
        painel.add(labelCurso);
        painel.add(rotuloSerie);
        painel.add(labelSerie);
        painel.add(voltarButton);
        painel.add(sairButton);
        setSize(450, 400);
        setVisible(true);
        setExtendedState(MAXIMIZED_BOTH);
    }
}
