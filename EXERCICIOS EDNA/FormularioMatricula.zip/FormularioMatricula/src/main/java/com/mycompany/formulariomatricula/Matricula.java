/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.formulariomatricula;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JFrame;

/**
 *
 * @author dti
 */
public class Matricula extends JFrame {
    JLabel rotulo1, rotulo2, rotulo3, rotulo4, rotulo5;
    JTextField texto1, texto2;
    JRadioButton etim, mtec, tecnico, ps, ss, ts;
    JTextArea texto;
    JScrollPane painelrolagem;
    JPanel painel;
    JComboBox<String> cursoComboBox;
    JButton limparButton, apresentarButton;

 public Matricula() {
        super("Formulário Matrícula");
        Container tela = getContentPane();
        ImageIcon icone = new ImageIcon("usuario.jpg");
        setIconImage(icone.getImage());
        setLayout(null);

        // JLABEL
        rotulo1 = new JLabel("DADOS CADASTRAIS DO ALUNO");
        rotulo2 = new JLabel("Nome: ");
        rotulo3 = new JLabel("Matricula: ");
        rotulo4 = new JLabel("INFORME OS DADOS DO SEU CURSO: ");
        rotulo5 = new JLabel("RESTRIÇÕES MEDICAS: ");
        etim = new JRadioButton("Etim");
        mtec = new JRadioButton("Mtec");
        tecnico = new JRadioButton("Tecnico");
        ps = new JRadioButton("1° serie");
        ss = new JRadioButton("2° serie");
        ts = new JRadioButton("3° serie");
        texto = new JTextArea(10, 20);
        painelrolagem = new JScrollPane(texto);

        // JComboBox
        String[] cursos = {"Selecione...", "Matutino", "Vespertino", "Noturno"};
        cursoComboBox = new JComboBox<>(cursos);

        // Tamanho da fonte
        Font fonte = rotulo1.getFont();
        rotulo1.setFont(fonte.deriveFont(fonte.getSize() + 5f)); // Aumenta em 5 pontos

        // Cor da fonte
        rotulo1.setForeground(Color.RED);

        // TextFields com tamanho 20
        texto1 = new JTextField(20);
        texto2 = new JTextField(20);

        // PAINEL DE ROLAGEM
        painel = new JPanel();
        painel.setLayout(null); // Defina o layout do painel como null

        painelrolagem.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        painelrolagem.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
       
        // SETBOUNDS
        rotulo1.setBounds(20, 20, 1000, 20);
        rotulo2.setBounds(20, 60, 50, 20);
        rotulo3.setBounds(20, 90, 100, 20);
        rotulo4.setBounds(20, 130, 1000, 20);
        rotulo5.setBounds(20, 250, 1000, 20);
        texto1.setBounds(100, 60, 250, 20);
        texto2.setBounds(100, 90, 250, 20);
        etim.setBounds(20, 155, 90, 20);
        mtec.setBounds(20, 175, 100, 20);
        tecnico.setBounds(20, 195, 100, 20);
        ps.setBounds(160, 155, 90, 20);
        ss.setBounds(160, 175, 100, 20);
        ts.setBounds(160, 195, 100, 20);
        cursoComboBox.setBounds(260, 160, 150, 20);
        painel.setBounds(20, 280, 390, 110);
        painelrolagem.setBounds(5, 10, 310, 100);
        apresentarButton.setBounds(120, 400, 150, 20);

        // Button Group para as opções ETIM, MTEC e Técnico
        ButtonGroup grupoOpcoes = new ButtonGroup();
        grupoOpcoes.add(etim);
        grupoOpcoes.add(mtec);
        grupoOpcoes.add(tecnico);

        // Button Group para as opções ps, ss, ts
        ButtonGroup grupoOpcoes2 = new ButtonGroup();
        grupoOpcoes2.add(ps);
        grupoOpcoes2.add(ss);
        grupoOpcoes2.add(ts);

        // ActionListener para remover "Selecione..." do JComboBox
        cursoComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (cursoComboBox.getItemAt(0).equals("Selecione...")) {
                    cursoComboBox.removeItemAt(0);
                }
            }
        });

        // Botão Limpar
        limparButton = new JButton("LIMPAR");
        limparButton.setBounds(20,400,80,20);
        limparButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Limpar os campos de texto
                texto1.setText("");
                texto2.setText("");
                texto.setText("");

                // Limpar a seleção da JComboBox
                cursoComboBox.setSelectedIndex(-1);

                // Limpar a seleção dos RadioButtons
                etim.setSelected(false);
                mtec.setSelected(false);
                tecnico.setSelected(false);
                ps.setSelected(false);
                ss.setSelected(false);
                ts.setSelected(false);

                // Limpar a seleção dos ButtonGroups
                grupoOpcoes.clearSelection();
                grupoOpcoes2.clearSelection();
            }
        });
    
        // Botão Apresentar Dados
        apresentarButton = new JButton("Apresentar Dados");
        apresentarButton.setBounds(120, 430, 150, 20);
        apresentarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nomee = texto1.getText();
                String matrice = texto2.getText();
                String cursoe = "";
                String seriee = "";
                String restre = texto.getText();
                String perioe = cursoComboBox.getSelectedItem().toString();

                if (ps.isSelected())
                    seriee = ps.getText();
                else if (ss.isSelected())
                    seriee = ss.getText();
                else if (ts.isSelected())
                    seriee = ts.getText();

                if (etim.isSelected())
                    cursoe = etim.getText();
                else if (mtec.isSelected())
                    cursoe = mtec.getText();
                else if (tecnico.isSelected())
                    cursoe = tecnico.getText();

                // Exibir os dados em uma nova janela
                frmMostrar mostra = new frmMostrar(nomee, matrice, restre, perioe, cursoe, seriee);
                mostra.setVisible(true);
                dispose();
            }
        });
           // Botão Sair
             JButton sairButton = new JButton("Sair");
             sairButton.setBounds(220, 400, 80, 20);
             sairButton.addActionListener(new ActionListener() {
             public void actionPerformed(ActionEvent e) {
             System.exit(0); // Finaliza o projeto
       }
       });
        // ADD NA TELA
        tela.add(rotulo1);tela.add(sairButton);
        tela.add(rotulo2);
        tela.add(rotulo3);
        tela.add(rotulo4);
        tela.add(texto1);
        tela.add(texto2);
        tela.add(etim);
        tela.add(mtec);
        tela.add(tecnico);
        tela.add(ts);
        tela.add(ss);
        tela.add(ps);
        tela.add(cursoComboBox);
        tela.add(rotulo5);
        tela.add(painel);
        tela.add(limparButton);
        painel.add(painelrolagem);
    setSize(450, 600);
    setVisible(true);
    setExtendedState(MAXIMIZED_BOTH);
   }
   
   public static void main (String args[]){
      Matricula app = new Matricula();
      app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }
}