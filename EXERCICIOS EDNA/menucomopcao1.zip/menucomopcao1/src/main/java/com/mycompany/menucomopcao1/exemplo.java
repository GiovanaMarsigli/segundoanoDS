/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.menucomopcao1;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 *
 * @author dti
 */
public class exemplo extends JFrame{
    JMenuBar barra; //Criar a barra de menus
    JMenu opcoes, cor, fonte;   
    JMenuItem limpar, sair, tamanho, azul, verde, vermelho, amarelo, preto; // Declarar na área pública a variavel que vai receber a barra da menu: JMENUBAR barra;
    JTextArea texto;
    JPanel painel;
    JScrollPane rolagem;
    
    public exemplo(){
    super("EXEMPLO DE MENUS");
    Container tela = getContentPane();
    tela.setLayout(null);
    barra = new JMenuBar();
    setJMenuBar(barra);
    opcoes = new JMenu ("OPÇÕES");
    barra.add(opcoes);
    ImageIcon icone = new ImageIcon("imgmenu.png");
    setIconImage(icone.getImage());
    
    //CRIAR OS ITENS DO MENU DE OPÇÕES
    limpar = new JMenuItem("Limpar");
    fonte = (JMenu) new JMenu("Fonte");
    cor = new JMenu("Cor");
    azul = new JMenuItem("Azul");
    verde = new JMenuItem("Verde"); 
    vermelho = new JMenuItem("Vermelho");
    amarelo = new JMenuItem("Amarelo");
    preto = new JMenuItem("Preto");
    tamanho = new JMenuItem("Tamanho");
    sair = new JMenuItem("Sair");
    texto = new JTextArea (10,20);
    painel = new JPanel();
    
    //DEFINIR AS TECLAS DE ATALHO PARA O MENU E TODOS OS ITENS DO MENU
    opcoes.setMnemonic(KeyEvent.VK_O);
    limpar.setMnemonic(KeyEvent.VK_L);
    fonte.setMnemonic(KeyEvent.VK_F);
    sair.setMnemonic(KeyEvent.VK_S);
    cor.setMnemonic(KeyEvent.VK_C);
    
    //ADICIONAR/ANEXAR ITENS MENU DE OPÇÃO
    opcoes.add(limpar);
    opcoes.add(fonte);
    opcoes.addSeparator();
    opcoes.add(sair);
    
    cor.add(azul);cor.add(verde);cor.add(vermelho);cor.add(amarelo);cor.add(preto);
    fonte.add(cor);
    
    
    //ROLAGEM
    rolagem = new JScrollPane(texto);
    rolagem.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    rolagem.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    painel.add(rolagem);
    painel.setBounds(30,30,250,185);
    tela.add(painel);
    
   //DANDO UTILIDADE AOS COMANDOS
   //LIMPAR-
   limpar.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
           texto.setText("");texto.requestFocus();}});
   
    azul.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            texto.setForeground(Color.blue);
            repaint();}});
    
    verde.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            texto.setForeground(Color.green);
            repaint();}});
    
   vermelho.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            texto.setForeground(Color.red);
            repaint();}});
    
    amarelo.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            texto.setForeground(Color.yellow);
            repaint();}});
    
    preto.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            texto.setForeground(Color.black); 
            repaint();}});
    
    sair.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            System.exit(0);}});
    
    tela.setBackground(new Color(255,255,201));
    setSize(500,300);
    setLocationRelativeTo(null);
    setVisible(true);
}
    public static void main(String args[]){
        exemplo app= new exemplo();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
} 