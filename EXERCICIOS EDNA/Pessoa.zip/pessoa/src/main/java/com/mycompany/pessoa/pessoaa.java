/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pessoa;
import javax.swing.JOptionPane;
/**
 *
 * @author dti
 */
public class pessoaa{

    //atributos 
    private String nome;
    private String endereco;
    private String telefone;
    
      //construtores
    //inicializa os atributos vazios
    public pessoaa() {
        this ("","","");
    }
        //inicializa os atributos com valores passados por parametro
    public pessoaa (String nome, String endereco, String telefone){
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
    }
      //Getters e Setters

    pessoaa(String string, String string0, String string1, String string2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    public static void main(String args[]){}
 
    public void InserirDadosPessoa(){
    setNome(JOptionPane.showInputDialog("Informe seu nome, por favor: "));
    setEndereco(JOptionPane.showInputDialog("Informe seu endereço, por favor: "));
    setTelefone(JOptionPane.showInputDialog("Informe seu telefone, por favor: "));

    }
  
    public void apresentarPessoa(){
    System.out.println("Seu nome é: " + this.getNome());
    System.out.println("Seu endereço e igual a: " + this.getEndereco());
    System.out.println("Seu número de telefone e igual a: " + this.getTelefone());
             }
         
            
     }
